package com.company.project.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

/**
 * 代码生成oracle Mapper
 *
 * @author wenbin
 * @version V1.0
 * @date 2020年3月18日
 */
@Mapper
@Component
public interface SysGeneratorOracleMapper extends GeneratorMapper {

}
